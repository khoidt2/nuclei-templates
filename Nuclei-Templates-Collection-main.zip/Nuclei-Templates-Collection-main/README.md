https://github.com/pikpikcu/nuclei-templates

https://github.com/esetal/nuclei-bb-templates

https://github.com/ARPSyndicate/kenzer-templates

https://github.com/medbsq/ncl

https://github.com/notnotnotveg/nuclei-custom-templates

https://github.com/clarkvoss/Nuclei-Templates

https://github.com/z3bd/nuclei-templates

https://github.com/peanuth8r/Nuclei_Templates

https://github.com/thebrnwal/Content-Injection-Nuclei-Script

https://github.com/ree4pwn/my-nuclei-templates

https://github.com/im403/nuclei-temp

https://github.com/System00-Security/backflow

https://github.com/geeknik/nuclei-templates-1

https://github.com/geeknik/the-nuclei-templates

https://github.com/optiv/mobile-nuclei-templates

https://github.com/obreinx/nuceli-templates

https://github.com/randomstr1ng/nuclei-sap-templates

https://github.com/CharanRayudu/Custom-Nuclei-Templates

https://github.com/n1f2c3/mytemplates

https://github.com/kabilan1290/templates

https://github.com/smaranchand/nuclei-templates

https://github.com/Saimonkabir/Nuclei-Templates

https://github.com/yavolo/nuclei-templates

https://github.com/sadnansakin/my-nuclei-templates

https://github.com/5cr1pt/templates

https://github.com/rahulkadavil/nuclei-templates

https://github.com/shifa123/detections

https://github.com/daffainfo/my-nuclei-templates

https://github.com/javaongsan/nuclei-templates

https://github.com/AshiqurEmon/nuclei_templates

https://gist.github.com/ResistanceIsUseless/e46848f67706a8aa1205c9d2866bff31

https://github.com/NitinYadav00/My-Nuclei-Templates

https://github.com/sharathkramadas/k8s-nuclei-templates

https://github.com/securitytest3r/nuclei_templates_work

https://github.com/MR-pentestGuy/nuclei-templates

https://github.com/thelabda/nuclei-templates

https://github.com/1in9e/my-nuclei-templates

https://github.com/redteambrasil/nuclei-templates

https://github.com/Saptak9983/Nuclei-Template

https://github.com/Harish4948/Nuclei-Templates

https://github.com/R-s0n/Custom_Vuln_Scan_Templates

https://github.com/meme-lord/Custom-Nuclei-Templates

https://github.com/Akokonunes/Private-Nuclei-Templates

https://github.com/rafaelwdornelas/my-nuclei-templates

https://github.com/rafaelcaria/Nuclei-Templates

https://github.com/panch0r3d/nuclei-templates

https://github.com/0x727/ObserverWard_0x727

https://github.com/ethicalhackingplayground/erebus-templates

https://github.com/test502git/log4j-fuzz-head-poc

https://github.com/Str1am/my-nuclei-templates

https://github.com/d3sca/Nuclei_Templates

https://github.com/c-sh0/nuclei_templates

https://github.com/glyptho/templatesallnuclei

https://github.com/0xAwali/Virtual-Host

https://github.com/praetorian-inc/chariot-launch-nuclei-templates

https://github.com/brinhosa/brinhosa-nuclei-templates

https://github.com/kh4sh3i/CVE-2022-23131

https://github.com/wr00t/templates

https://github.com/alexrydzak/rydzak-nuclei-templates

https://github.com/adampielak/nuclei-templates

https://github.com/ShangRui-hash/my-nuclei-templates

https://github.com/dk4trin/templates-nuclei

https://github.com/Elsfa7-110/mynuclei-templates

https://github.com/ping-0day/templates

https://github.com/wasp76b/nuclei-templates

https://github.com/th3r4id/nuclei-templates

https://github.com/justmumu/SpringShell

https://github.com/trickest/log4j

https://github.com/toramanemre/apache-solr-log4j-CVE-2021-44228

https://github.com/toramanemre/log4j-rce-detect-waf-bypass

https://github.com/blazeinfosec/nuclei-templates

https://github.com/ekinsb/Nuclei-Templates

https://github.com/KeepHowling/all_freaking_nuclei_templates

https://github.com/Odayex/Random-Nuclei-Templates

https://github.com/aels/CVE-2022-37042

https://github.com/tamimhasan404/Open-Source-Nuclei-Templates-Downloader

https://github.com/pentest-dev/Profesional-Nuclei-Templates

https://github.com/badboy-sft/badboy_17-Nuclei-Templates-Collection

https://github.com/NightRang3r/misc_nuclei_templates

https://github.com/ExpLangcn/NucleiTP

https://github.com/0xmaximus/final_freaking_nuclei_templates

https://github.com/Jagomeiister/nuclei-templates

https://github.com/ricardomaia/nuclei-template-generator-for-wordpress-plugins

https://github.com/Lopseg/nuclei-c-templates

https://github.com/sl4x0/NC-Templates

https://github.com/thecyberneh/nuclei-templatess

https://github.com/yarovit-developer/nuclei-templates

https://github.com/cipher387/juicyinfo-nuclei-templates

https://github.com/Kaue-Navarro/Templates-kaue-nuclei

https://github.com/JoshMorrison99/url-based-nuclei-templates

https://github.com/ayadim/Nuclei-bug-hunter

https://github.com/soumya123raj/Nuclei

https://github.com/soapffz/myown-nuclei-poc

https://github.com/zer0yu/Open-PoC

https://github.com/SumedhDawadi/Custom-Nuclei-Template

https://github.com/coldrainh/nuclei-ByMyself

https://github.com/binod235/nuclei-templates-and-reports

https://github.com/mbskter/Masscan2Httpx2Nuclei-Xray

https://github.com/luck-ying/Library-YAML-POC

https://github.com/PedroFerreira97/nuclei_templates

https://github.com/Hunt2behunter/nuclei-templates

https://github.com/mastersir-lab/nuclei-yaml-poc

https://github.com/SirAppSec/nuclei-template-generator-log4j

https://github.com/0xPugazh/my-nuclei-templates

https://github.com/topscoder/nuclei-wordfence-cve

https://github.com/erickfernandox/nuclei-templates

https://github.com/damon-sec/Nuclei-templates-Collection

https://github.com/DoubleTakes/nuclei-templates

https://github.com/ptyspawnbinbash/template-enhancer

https://github.com/Arvinthksrct/alltemplate

https://github.com/srkgupta/cent-nuclei-templates

https://github.com/UltimateSec/ultimaste-nuclei-templates

https://github.com/xinZa1/template

https://github.com/SirBugs/Priv8-Nuclei-Templates

https://github.com/davidfortytwo/GetNucleiTemplates

https://github.com/v3l4r10/Nuclei-Templates

https://github.com/wearetyomsmnv/llm_integrated_nuclei_templates

https://github.com/U53RW4R3/nuclei-fuzzer-templates

https://github.com/edoardottt/missing-cve-nuclei-templates

https://github.com/szybnev/nuclei-custom

https://github.com/r3dcl1ff/Symfony-Fuck

https://github.com/RandomRobbieBF/nuclei-drupal-sa

https://github.com/ed-red/redmc_custom_templates_nuclei

https://github.com/imhunterand/nuclei-custom-templates

https://github.com/vulnspace/nuclei-templates

https://github.com/microphone-mathematics/custom-nuclei-templates

https://github.com/valaDevs/nuclei-backupfile-finder

https://github.com/h0tak88r/nuclei_templates

https://github.com/solo10010/solo-nuclei-templates

https://github.com/zerbaliy3v/custom-nuclei-templates

https://github.com/Excis3/bans4-nuclei

https://github.com/Dalaho-bangin/my_nuclei_templates

https://github.com/pikpikcu/nuclei-fuzz

https://github.com/bhataasim1/PersonalTemplates

https://github.com/reewardius/log4shell-templates

https://github.com/0xKayala/Custom-Nuclei-Templates

https://github.com/VulnExpo/nuclei-templates

https://github.com/thanhnx9/nuclei-templates-cutomer

https://github.com/nvsecurity/nightvision-nuclei-templates

https://github.com/Red-Darkin/Custom-Nuclei-Templates

https://github.com/h4ndsh/nuclei-templates

https://github.com/EslamMonex/subdomain-takeover

https://github.com/kh4sh3i/Webmin-CVE

https://github.com/umityn/my-nuclei-templates

https://github.com/badboycxcc/CVE-2023-24100

https://github.com/qaisarafridi/MY-Nuclei-Templates

https://github.com/damon-sec/TCSZ-Nuclei

https://github.com/mdsabbirkhan/0xPugazh-my-nuclei-templates

https://github.com/0x71rex/0-Nuclei-Templates

https://github.com/projectdiscovery/nuclei-templates

https://github.com/0x71rex/0-fuzzing-templates

https://github.com/0x727/ObserverWard

https://github.com/0xAwali/Blind-SSRF

https://github.com/Lu3ky13/Authorization-Nuclei-Templates

https://github.com/PedroF-369/nuclei_templates

https://github.com/boobooHQ/private_templates

https://github.com/bug-vs-me/nuclei

https://github.com/freakyclown/Nuclei_templates

https://github.com/pikpikcu/my-nuclei-templates

https://github.com/rix4uni/BugBountyTips

https://github.com/themoonbaba/private_templates

https://github.com/0xElkot/My-Nuclei-Templates

https://github.com/themoonbaba/private_templates/blob/main/springboot_heapdump.yaml

https://github.com/NoRed0x/nored0x-Nuclei-Templates

https://github.com/rxerium/CISA-KEV

https://github.com/HideNsec/nuclei-bitrix-templates

https://github.com/reewardius/interested-nuclei-templates

https://github.com/HernanRodriguez1/ScanReflectedSSTI

https://github.com/praetorian-inc/zeroqlik-detect

https://github.com/zodmagus/z0ds3c-Nuclei-Templates

https://github.com/Mr-xn/CVE-2023-23333

https://github.com/BagheeraAltered/FuzzingTemplate

https://github.com/Shakilll/my_nuclei_templates

https://github.com/vijay922/XXE-FUZZ

https://github.com/topscoder/nuclei-zero-day

https://github.com/JoshMorrison99/my-nuceli-templates

https://github.com/20142995/nuclei-templates

https://github.com/JohnDoeAnonITA/NucleiTemplatePRV

https://github.com/Co5mos/nuclei-tps

https://github.com/al00000000al/my_nuclei_templates

https://github.com/madisec/nuclei-templates

https://github.com/Caddyshack2175/nuclei-custom-templates

https://github.com/0xc4sper0/Nuclei-templates

