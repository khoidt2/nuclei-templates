# Helper Commands

## Find all yaml files and sort them

```bash
find . -type f \( -iname "*.yaml" -o -iname "*.yml" \)| sort > sorted_yaml_files.txt
```
